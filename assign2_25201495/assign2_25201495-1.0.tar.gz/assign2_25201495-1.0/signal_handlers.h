#ifndef SIGNAL_HANDLERS_H
#define SIGNAL_HANDLERS_H

/*
Name: Ethan Epperson
Student Number: 25201495
Email: ethan.epperson@ucdconnect.ie
*/

void handle_sigint(int sig);
void setup_signal_handlers();

#endif
